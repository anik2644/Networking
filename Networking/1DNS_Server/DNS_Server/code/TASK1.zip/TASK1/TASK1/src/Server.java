import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class Server {

   static int Search(String s)
   {
       int i;
       int ret=0;
       String rs="nf";
       for(i=0;i<IPSearch.list.size();i++)
       {
           //System.out.println(s);
           if(IPSearch.list.get(i).Name.equals(s))
           {

               rs = IPSearch.list.get(i).Type;
               IPSearch.index=i;

               break;

           }
       }

       String MX= "MX";
       String NS= "NS";
       System.out.println(rs);

       if(rs.trim().equals("NS"))
   {
       System.out.println("hello");
       return 1;
   }
      else if(rs.trim().equals("MX"))
       {
         return 5;
       }
      else if(rs.trim().equals("nf"))
       {
           System.out.println("hello");
           return 0;
       }

       else if(rs.trim().equals("CNAME"))
       {
           return 2;
       }
       else if(rs.trim().equals("AAAA"))
       {
           return 3;
       }
       else if(rs.trim().equals("A"))
       {
           return 4;
       }

       return ret;
   }

    public static void main(String[] args) throws Exception {


        IPSearch.create_list();
        int flag= 0;
        String response = "Welcome to CSE 3111!";
        // Create a DatagramSocket
        int port = 1500;

        DatagramSocket socket = new DatagramSocket(port);
        System.out.println("Domain server Started");

        // Receive a message from the client
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        socket.receive(packet);
        String message = new String(packet.getData(), 0, packet.getLength());
        System.out.println("Client message: " + message);


        flag = Search(message);
        System.out.println(flag);


          if(flag==0)
          {
              response = "Not Found";
          }
        else if(flag==1)
        {
            response = "NS type domain";
        }
          else if(flag==2)
          {
              response = "Cname type domain";
          }
          else if(flag==3)
          {
              flag = Search(IPSearch.list.get(IPSearch.index).Name);

              response = IPSearch.list.get(IPSearch.index).Value;
          }
          else if(flag==4)
          {
              response = "A type domain";
              response= IPSearch.list.get(IPSearch.index).Value;
          }
          else if(flag==5)
          {
              response = "MX type domain";
          }



        // Send a response to the client
        //String response = "Welcome to CSE 3111!";
        buffer = response.getBytes();
        packet = new DatagramPacket(buffer, buffer.length, packet.getAddress(), packet.getPort());
        socket.send(packet);

        // Close the socket
        socket.close();
    }
}
