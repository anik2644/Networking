import java.util.ArrayList;
import java.util.List;

public class IPSearch {
        static int index;
        static List<IPSearch> list=new ArrayList<IPSearch>();
            String Name;
            String Value;
            String Type;
            String TTL;
            IPSearch(String Name,String Value,String Type,String TTL){
            this.Name=Name;
             this.Value=Value;
           this.Type =Type;
           this.TTL=TTL;
            }


            static void create_list()
            {


                IPSearch ins=new IPSearch("cse.du.ac.bd.", "ns1.cse.du.ac.bd.","NS ","86400");
                    list.add(ins);
                IPSearch ins1=new IPSearch("cse.du.ac.bd.", "ns2.cse.du.ac.bd.","NS ","86400");
                    list.add(ins1);
                IPSearch  ins2=new IPSearch("ns1.cse.du.ac.bd.", "192.0.2.1","A","86400");
                    list.add(ins2);
                IPSearch   ins3=new IPSearch("ns2.cse.du.ac.bd.", "192.0.2.2","A","86400");
                    list.add(ins3);
                IPSearch    ins4=new IPSearch("ns1.cse.du.ac.bd.", "2001:db8::1","AAAA","86400");
                    list.add(ins4);
                IPSearch  ins5=new IPSearch("ns2.cse.du.ac.bd.", " 2001:db8::2","AAAA","86400");
                    list.add(ins5);
                IPSearch  ins6=new IPSearch("cse.du.ac.bd. ", "192.0.2.3","A","86400");
                    list.add(ins6);
                IPSearch  ins7=new IPSearch("cse.du.ac.bd.", "2001:db8::3","AAAA","86400");
                    list.add(ins7);
                IPSearch     ins8=new IPSearch("www.cse.du.ac.bd.", "cse.du.ac.bd.","CNAME","86400");
                    list.add(ins8);
                IPSearch  ins9=new IPSearch("cse.du.ac.bd.", "10 mail.cse.du.ac.bd.","MX","86400");
                    list.add(ins9);
                IPSearch  ins10=new IPSearch("mail.cse.du.ac.bd.", "192.0.2.4","A","86400");
                    list.add(ins10);
                IPSearch   ins11=new IPSearch("mail.cse.du.ac.bd.", "2001:db8::4","AAAA","86400");
                    list.add(ins11);

//
//                for(int i=0;i<IPSearch.list.size();i++)
//                {
//                    System.out.println(IPSearch.list.get(i).Name);
//
//                }

            }
}